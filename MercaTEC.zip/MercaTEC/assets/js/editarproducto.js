document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('formProdu');
    form.addEventListener('submit', function (event) {
        event.preventDefault();  // Detiene el envío predeterminado del formulario

        // Captura los valores de los campos del formulario
        const nombreProducto = document.getElementById('nombreP').value;
        const cantidad = document.getElementById('cantidad').value;
        const descrip = document.getElementById('descripcion').value;


        console.log('NombreP:', nombreProducto);
        console.log('Cantidad:', cantidad);
        console.log('Descripción:', descrip);

        alert(localStorage.getItem('idProducto'));
        fetch(`http://localhost:3000/updateProducto/${localStorage.getItem('idProducto')}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nombre: nombre,
                apellidos: apellidos,
                numero: numero,
                biografia: biografia,
                contrasenna: contrasenna
            })
        })
        .then(response => response.text())
        .then(data => {
            if (data === 'Usuario actualizado correctamente.') {
                alert('Usuario actualizado con éxito');
                localStorage.setItem( 'nombre', nombre);
                localStorage.setItem( 'apellidos', apellidos);
                localStorage.setItem( 'numero', numero);
                localStorage.setItem( 'biografia', biografia);
                localStorage.setItem( 'contrasenna', contrasenna);
                window.location.href = 'Usuario principal.html';  // O redirigir a otra página según necesario
            } else {
                alert('No se pudo actualizar el usuario.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al actualizar el usuario.');
        });
        

        // Aquí podrías hacer algo con estos datos, como enviarlos a un servidor
    });
});



function cargarDatos(){
    document.getElementById('name').value = localStorage.getItem('nombre');
    document.getElementById('surname').value = localStorage.getItem('apellidos');
    document.getElementById('number').value = localStorage.getItem('numero');
    document.getElementById('biography').value = localStorage.getItem('biografia');
    document.getElementById('contrasenna').value = localStorage.getItem('contrasenna');
    document.getElementById('confirm-password').value = localStorage.getItem('contrasenna');
}

cargarDatos();